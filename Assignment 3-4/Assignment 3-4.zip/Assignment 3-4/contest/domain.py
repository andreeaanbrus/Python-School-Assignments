def createScore(P1, P2, P3):
    '''
    :param P1: first score
    :param P2: second score
    :param P3: third score
    :return: the dictionary containing the score of a contestant
    '''
    return {"P1" : P1, "P2" : P2, "P3" : P3}